using UnityEngine;


public class PlayerControl : MonoBehaviour
{
    public float accel_speed = 7;
    public float accel_rotate = 6;

    public float friction = 0.8f;

    public Vector3 speed_velocity = new (0f, 0f, 0f);
    public Vector3 turning_velocities = new (0f, 0f, 0f);

    public SimplePID y_pid = new();
    public SimplePID x_pid = new();
    public float prop = 1;
    public float inte = 0;
    public float derivative = 0;

    public float bias = 0;
    public float set_point = 0;


    // public Vector3[] velocity_vectors = new Vector3(new Vector3(), )

    //  Representation of 3D vectors and points.
    Vector3 SpeedControls() {
        
        float speedY = Input.GetAxisRaw("Horizontal") * accel_speed * Time.deltaTime;
        float speedX = Input.GetAxisRaw("Vertical") * accel_speed * Time.deltaTime;

        return new Vector3(speedX, speedY, 0.0f);
    }

    Vector3 RotationControls() {
        Vector3 accel_rotation_states = new (0f, 0f, 0f);
        float z_rot_value = accel_rotate * -Input.GetAxisRaw("Player rotation right");
        if (z_rot_value != 0f) {
            accel_rotation_states[2] = accel_rotate * accel_rotate * z_rot_value * Time.deltaTime;
        }
        // Debug.Log(rot_value * Time.deltaTime);
        // Debug.Log(Input.GetAxisRaw("Player rotation right"));
        return accel_rotation_states;
    }

    Vector3 Accel_to_velocity(Vector3 velocity_vector, Vector3 accel_vector) {
        return velocity_vector += accel_vector;
        // for (int i = 0; i < 3; i++) {
        //     // if (i == 2)
        //         // velocity_vector[i] += y_pid.Update(accel_vector[i]);
        //         // Debug.Log("executed");
        //     velocity_vector[i] += accel_vector[i];
            
        // }
        // // Debug.Log(velocity_vector[0]);
        // return velocity_vector;
    }

    Vector3 Apply_friction(Vector3 vector) {
        return vector * (1 - friction);
    }


    // Start is called before the first frame update
    void Start()
    {
        y_pid.Setup(prop, inte, derivative, bias, set_point);
        x_pid.Setup(prop, inte, derivative, bias, set_point);

    }

    // Update is called once per frame
    void Update()
    {
        Vector3 turn_velocity = Apply_friction(turning_velocities);
        Vector3 turn_accell = RotationControls();
        // Debug.Log(turn_accell);
        turning_velocities = Accel_to_velocity(turn_velocity, turn_accell);
        speed_velocity = Accel_to_velocity(Apply_friction(speed_velocity), SpeedControls());

        
        // Space.World
        speed_velocity[0] += x_pid.Update(speed_velocity[0]);
        speed_velocity[1] += y_pid.Update(speed_velocity[1]);
        transform.Translate(speed_velocity, Space.Self);
        // RotationControls(Time.deltaTime);
        transform.Rotate(turning_velocities);
    }
}
