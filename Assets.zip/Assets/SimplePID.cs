using UnityEngine;

public class SimplePID {
    private float error_prior;
    private float integral_prior;
    private float coef_Prop;
    private float coef_Inte;
    private float coef_Deriv;

    private float bias;

    private float set_point;
    private float current_value;

    private float PID_Step() {
        float error = set_point - current_value;
        float integral = integral_prior + (error * Time.deltaTime);
        float derivative = (error - error_prior) / Time.deltaTime;
        float output = coef_Prop * error + coef_Inte * integral + coef_Deriv * derivative + bias;
        error_prior = error;
        integral_prior = integral;
        
        return output;
    }

    public void Setup(float Prop, float integral, float derivative, float bias, float target) {
        coef_Prop = Prop;
        coef_Inte = integral;
        coef_Deriv = derivative;
        this.bias = bias;
        set_point = target;
    }

    public float Update(float current_value) {
        this.current_value += current_value;
        // Debug.Log(current_value);
        this.current_value = PID_Step();
        return this.current_value;
    }

    public void Set_value(float value) {
        current_value = value;
    }

    public float Get_value() {
        return current_value;
    }
}