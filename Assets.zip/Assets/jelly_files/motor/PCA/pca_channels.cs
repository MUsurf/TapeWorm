
public class PCA_channel {
    public int duty_cycle = 0;
    public int pin_id;

    public void Setup(int duty_cycle, int pin_id) {
        this.duty_cycle = duty_cycle;
        this.pin_id = pin_id;
    }
}