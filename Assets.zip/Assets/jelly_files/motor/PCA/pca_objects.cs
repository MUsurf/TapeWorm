using System.Linq;

public class PCAObject{
    public int frequency;

    public int duty_cycle;
    public PCA_channel[] pca_channels;


    public void Create_pca_channel(int frequency, int duty_cycle=0) {
        this.frequency = frequency;
        this.duty_cycle = duty_cycle;

        // PCA_channel pca_channel = new();
        // pca_channel.Setup(duty_cycle, channel_id);
        // pca_channels.Append(pca_channel);
    }
}