
using System.Linq;

public class MotorCommander {
    private readonly PCAObject pca = new();

    private int num_motors;
    private int step_size;
    private float minor_time;

    private int[] motor_direction;
    private int[] pinStates;
    // Currently dummy values included to maintain compat with python code
    private PCAObject[] motors;



    
    public void Setup(int number_motors, int step_size, int minor_time, int frequency) {
        num_motors = number_motors;
        for (int i = 0; i < num_motors; i++) {
            motor_direction[i] = 1;
            pinStates[i] = 0;
            motors[i] = new PCAObject();
        }
        this.step_size = step_size;
        this.minor_time = minor_time;

        pca.frequency = frequency;
    }

    public void SetMotorSpeed(int motor_index, int motor_speed) {
        // Set speed of a single motor
        int pwm_value = MicroSecDuty(1000 + (motor_speed * 10));
        motors[motor_index].duty_cycle = pwm_value;
    }

    public void PinStep(int[] targets) {
        int[] directions = TargetDistance(targets);
        for (int i = 0; i < directions.Length; i++) {
            // if (directions[i] == 0) {
            //     continue;
            // }
            pinStates[i] += directions[i] * step_size;
        }
        SetMotors(pinStates);
    }

    private int MicroSecDuty(int microseconds) {
        float samp_time = 1/pca.frequency * 1000 *
            1000;  // Convert to Micro Sec
        int duty_cycle = (int)(65536 * microseconds / samp_time);
        return duty_cycle;
    }

    private int[] TargetDistance(int[] targets) {
        int[] directions = new int[num_motors];
        for (int i = 0; i < targets.Length; i++) {
            int value = targets[i] - pinStates[i];
            if (value == 0) {
                directions.Append(0);
            } else if (value > 0) {
                directions.Append(1);
            } else {
                directions.Append(-1);
            }
        }
        return directions;
    }

    private void SetMotors(int[] targets) {
        for (int index = 0; index < targets.Length; index++) {
            SetMotorSpeed(index, targets[index]);
        }
    }

    public void Update(int[] message_rec) {
        // """Function to subscribe to driver with ros"""
        for (int index = 0; index < message_rec.Length; index++) {
            motors[index].duty_cycle = MicroSecDuty(message_rec[index]);
        }
    }
}