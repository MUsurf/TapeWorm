using UnityEngine;


public class player : MonoBehaviour
{
    public float speed;
    void Start()
    {
        speed = 1;
    }

    void Update()
    {
        transform.Translate(Vector3.left * Time.deltaTime* speed);
    }
}